package com.autoclickscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * The whole automation lives here, independent from MainActivity.
 * It only stops on STOP, or when this service is disconnected.
 */
class ClickerService : AccessibilityService() {

    companion object {
        @Volatile var instance: ClickerService? = null
        val connected = MutableStateFlow(false)
        val running = MutableStateFlow(false)
        val picking = MutableStateFlow(false)

        private const val TAP_MS = 50L
        private const val SWIPE_MS = 400L
        private const val MAX_FAILS = 15
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var picker: PickerOverlay? = null
    private var stopChip: StopChip? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    // The system calls this when switching apps/focus. It must NOT stop the automation.
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }

    private fun shutdown() {
        job?.cancel()
        job = null
        picker?.dismiss()
        picker = null
        stopChip?.hide()
        stopChip = null
        instance = null
        connected.value = false
        running.value = false
        picking.value = false
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------------- Automation ----------------

    fun startCycle(): Boolean {
        if (running.value) return true
        if (picker != null) {
            toast("ابتدا انتخاب مختصات را تمام یا لغو کنید")
            return false
        }
        val p = Config.load(this)
        if (p == null) {
            toast("مختصات یا Delay نامعتبر است")
            return false
        }
        running.value = true
        showStopChip()
        job = scope.launch {
            var fails = 0
            try {
                while (isActive) {
                    val ok1 = tap(p.x1, p.y1)
                    if (!isActive) break
                    val ok2 = swipe(p.startX, p.startY, p.endX, p.endY)
                    if (!isActive) break
                    delay(p.delayMs)
                    if (!isActive) break
                    val ok3 = tap(p.x2, p.y2)

                    if (ok1 && ok2 && ok3) {
                        fails = 0
                    } else {
                        fails++
                        if (fails >= MAX_FAILS) {
                            toast("اجرای حرکت روی صفحه چند بار پشت سر هم ناموفق بود؛ متوقف شد")
                            break
                        }
                        delay(300)
                    }
                }
            } finally {
                running.value = false
                hideStopChip()
            }
        }
        return true
    }

    fun stopCycle() {
        job?.cancel()
        job = null
        running.value = false
        hideStopChip()
    }

    private fun showStopChip() {
        if (stopChip == null) stopChip = StopChip(this) { stopCycle() }
        stopChip?.show()
    }

    private fun hideStopChip() {
        stopChip?.hide()
    }

    private suspend fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return gesture(path, TAP_MS)
    }

    private suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(path, SWIPE_MS)
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
                .build()
            val dispatched = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!dispatched && cont.isActive) cont.resume(false)
        }

    // ---------------- Coordinate picking ----------------

    fun startPick(steps: List<PickStep>): Boolean {
        if (running.value) {
            toast("ابتدا STOP را بزنید")
            return false
        }
        picker?.dismiss()
        val po = PickerOverlay(this, steps) { completed ->
            picker = null
            picking.value = false
            if (completed) {
                toast("مختصات ذخیره شد")
                openApp()
            }
        }
        picker = po
        picking.value = true
        po.show()
        return true
    }

    private fun openApp() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (_: Exception) {
        }
    }
}
