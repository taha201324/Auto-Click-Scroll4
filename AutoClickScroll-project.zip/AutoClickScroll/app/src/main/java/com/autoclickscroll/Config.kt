package com.autoclickscroll

import android.content.Context

data class Params(
    val x1: Float, val y1: Float,
    val x2: Float, val y2: Float,
    val startX: Float, val startY: Float,
    val endX: Float, val endY: Float,
    val delayMs: Long
)

object Config {
    private const val FILE = "cfg"
    val NUM_KEYS = listOf("x1", "y1", "x2", "y2", "startx", "starty", "endx", "endy")

    fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Reads the saved configuration. Returns null if any value is missing/invalid. */
    fun load(c: Context): Params? {
        val p = prefs(c)
        val v = NUM_KEYS.map { p.getString(it, null)?.trim()?.toFloatOrNull() }
        val d = p.getString("delay", "1000")?.trim()?.toLongOrNull()
        if (v.any { it == null } || d == null || d < 0) return null
        return Params(v[0]!!, v[1]!!, v[2]!!, v[3]!!, v[4]!!, v[5]!!, v[6]!!, v[7]!!, d)
    }
}
