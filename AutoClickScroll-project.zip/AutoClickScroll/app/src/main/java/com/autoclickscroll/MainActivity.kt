package com.autoclickscroll

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val fields = LinkedHashMap<String, EditText>()
    private val pickButtons = ArrayList<Button>()
    private lateinit var statusView: TextView
    private lateinit var startBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun pickBtn(text: String, steps: List<PickStep>) = Button(this).apply {
        this.text = text
        setOnClickListener { onPick(steps) }
        pickButtons.add(this)
    }

    private fun group(
        root: LinearLayout, label: String,
        kx: String, ky: String, defX: Int, defY: Int,
        pickText: String, steps: List<PickStep>
    ) {
        root.addView(TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, dp(12), 0, 0)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((k, d, hint) in listOf(Triple(kx, defX, "X"), Triple(ky, defY, "Y"))) {
            val et = EditText(this).apply {
                this.hint = hint
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(d.toString())
            }
            fields[k] = et
            row.addView(et, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)
        root.addView(pickBtn(pickText, steps), lp(0))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Auto Click Scroll"

        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Auto Click Scroll"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })
        statusView = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(statusView)

        group(root, "Point 1", "x1", "y1", w / 2, h / 2, "انتخاب Point 1", listOf(PickStep.P1))
        group(root, "Point 2", "x2", "y2", w / 2, h * 3 / 4, "انتخاب Point 2", listOf(PickStep.P2))
        group(root, "Scroll Start", "startx", "starty", w / 2, h * 3 / 4, "انتخاب شروع Scroll", listOf(PickStep.SS))
        group(root, "Scroll End", "endx", "endy", w / 2, h / 4, "انتخاب پایان Scroll", listOf(PickStep.SE))

        root.addView(pickBtn("انتخاب Scroll (شروع و سپس پایان)", listOf(PickStep.SS, PickStep.SE)), lp(12))
        root.addView(
            pickBtn("انتخاب همه به ترتیب (Point 1، Scroll، Point 2)",
                listOf(PickStep.P1, PickStep.SS, PickStep.SE, PickStep.P2)),
            lp(4)
        )

        root.addView(TextView(this).apply {
            text = "مکث بعد از Scroll (میلی‌ثانیه)"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0, dp(12), 0, 0)
        })
        fields["delay"] = EditText(this).apply {
            hint = "Delay (ms)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("1000")
        }
        root.addView(fields["delay"])

        root.addView(Button(this).apply {
            text = "فعال‌کردن Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, lp(16))

        startBtn = Button(this).apply {
            text = "START"
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#2E7D32"))
            setOnClickListener { onStartClicked() }
        }
        root.addView(startBtn, lp(8))

        root.addView(Button(this).apply {
            text = "STOP"
            setTextColor(Color.WHITE)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#C62828"))
            setOnClickListener { ClickerService.instance?.stopCycle() }
        }, lp(8))

        setContentView(ScrollView(this).apply { addView(root) })

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                var prevRunning = false
                var stopped = false
                combine(
                    ClickerService.connected,
                    ClickerService.running,
                    ClickerService.picking
                ) { c, r, p -> Triple(c, r, p) }.collect { (connected, running, picking) ->
                    if (prevRunning && !running) stopped = true
                    if (running) stopped = false
                    prevRunning = running

                    val (text, color) = when {
                        !connected -> "Accessibility فعال نیست" to "#C62828"
                        picking -> "در حال انتخاب مختصات" to "#EF6C00"
                        running -> "در حال اجرا" to "#2E7D32"
                        stopped -> "متوقف شده" to "#616161"
                        else -> "آماده اجرا" to "#1565C0"
                    }
                    statusView.text = text
                    statusView.setTextColor(Color.parseColor(color))
                    startBtn.isEnabled = connected && !running && !picking
                    pickButtons.forEach { it.isEnabled = connected && !running }
                    fields.values.forEach { it.isEnabled = !running }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadFields()
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    private fun loadFields() {
        val p = Config.prefs(this)
        for ((k, et) in fields) {
            p.getString(k, null)?.let { et.setText(it) }
        }
    }

    private fun saveFields() {
        val e = Config.prefs(this).edit()
        for ((k, et) in fields) e.putString(k, et.text.toString().trim())
        e.apply()
    }

    private fun fieldsValid(): Boolean {
        val numsOk = Config.NUM_KEYS.all { fields[it]?.text?.toString()?.trim()?.toFloatOrNull() != null }
        val d = fields["delay"]?.text?.toString()?.trim()?.toLongOrNull()
        return numsOk && d != null && d >= 0
    }

    private fun onPick(steps: List<PickStep>) {
        val svc = ClickerService.instance
        if (svc == null) {
            toast("ابتدا سرویس Auto Click Scroll را در Settings → Accessibility فعال کنید")
            return
        }
        saveFields()
        if (svc.startPick(steps)) {
            toast("به برنامه مقصد بروید و از نوار کنترل پایین صفحه «شروع انتخاب» را بزنید")
            moveTaskToBack(true)
        }
    }

    private fun onStartClicked() {
        val svc = ClickerService.instance
        if (svc == null) {
            toast("ابتدا سرویس Auto Click Scroll را در Settings → Accessibility فعال کنید")
            return
        }
        if (!fieldsValid()) {
            toast("همه فیلدها را با عدد معتبر پر کنید")
            return
        }
        saveFields()
        if (svc.startCycle()) {
            toast("اجرا شروع شد. برای توقف، دکمه قرمز STOP روی صفحه را بزنید")
            moveTaskToBack(true)
        }
    }
}
