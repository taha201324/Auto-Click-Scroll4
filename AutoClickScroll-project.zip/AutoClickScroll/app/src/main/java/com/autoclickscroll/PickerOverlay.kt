package com.autoclickscroll

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

enum class PickStep(val label: String, val kx: String, val ky: String, val mark: String) {
    P1("Point 1", "x1", "y1", "P1"),
    P2("Point 2", "x2", "y2", "P2"),
    SS("شروع Scroll", "startx", "starty", "S"),
    SE("پایان Scroll", "endx", "endy", "E")
}

/** Full-screen view that shows marks and reports the exact raw screen coordinates of a touch. */
class PickView(context: Context) : View(context) {
    var capture = false
    var onPick: ((Float, Float) -> Unit)? = null

    private val marks = LinkedHashMap<String, PointF>()
    private var cur: PointF? = null
    private val density = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * density
        isFakeBoldText = true
    }
    private val loc = IntArray(2)

    private fun colorFor(name: String): Int = when (name) {
        "P1" -> Color.parseColor("#2E7D32")
        "P2" -> Color.parseColor("#1565C0")
        "S" -> Color.parseColor("#EF6C00")
        else -> Color.parseColor("#C62828")
    }

    fun setMark(name: String, x: Float, y: Float) {
        marks[name] = PointF(x, y)
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!capture) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                cur = PointF(e.rawX, e.rawY)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                cur = null
                invalidate()
                onPick?.invoke(e.rawX, e.rawY)
            }
            MotionEvent.ACTION_CANCEL -> {
                cur = null
                invalidate()
            }
        }
        return true
    }

    private fun drawCross(c: Canvas, x: Float, y: Float, color: Int) {
        line.color = color
        val r = 16f * density
        val l = 30f * density
        c.drawCircle(x, y, r, line)
        c.drawLine(x - l, y, x + l, y, line)
        c.drawLine(x, y - l, x, y + l, line)
    }

    override fun onDraw(canvas: Canvas) {
        if (capture) canvas.drawColor(Color.argb(60, 255, 152, 0))
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()

        val s = marks["S"]
        val en = marks["E"]
        if (s != null && en != null) {
            line.color = colorFor("S")
            canvas.drawLine(s.x - ox, s.y - oy, en.x - ox, en.y - oy, line)
        }
        for ((name, p) in marks) {
            val x = p.x - ox
            val y = p.y - oy
            drawCross(canvas, x, y, colorFor(name))
            fill.color = colorFor(name)
            tp.color = Color.WHITE
            val w = tp.measureText(name)
            canvas.drawRect(x + 18f * density, y - 34f * density, x + 18f * density + w + 12f * density, y - 8f * density, fill)
            canvas.drawText(name, x + 24f * density, y - 14f * density, tp)
        }

        val c = cur
        if (c != null) {
            val x = c.x - ox
            val y = c.y - oy
            drawCross(canvas, x, y, Color.WHITE)
            val label = "X=${c.x.roundToInt()}   Y=${c.y.roundToInt()}"
            val w = tp.measureText(label)
            var tx = x - w / 2
            tx = tx.coerceIn(8f * density, (width - w - 8f * density).coerceAtLeast(8f * density))
            var ty = y - 90f * density
            if (ty < 60f * density) ty = y + 110f * density
            fill.color = Color.argb(215, 0, 0, 0)
            canvas.drawRect(tx - 8f * density, ty - 24f * density, tx + w + 8f * density, ty + 10f * density, fill)
            canvas.drawText(label, tx, ty, tp)
        }
    }
}

/**
 * Shows (1) a full-screen overlay that records touches and (2) a small control bar.
 * Uses TYPE_ACCESSIBILITY_OVERLAY, the official overlay type for accessibility services
 * (no extra permission needed).
 */
class PickerOverlay(
    private val service: AccessibilityService,
    private val steps: List<PickStep>,
    private val onFinish: (completed: Boolean) -> Unit
) {
    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = Config.prefs(service)
    private val handler = Handler(Looper.getMainLooper())

    private var index = 0
    private var capturing = false
    private var alive = true
    private var done = false
    private var barOnTop = false
    private var lastMsg = ""

    private val pickView = PickView(service)
    private val bar = LinearLayout(service)
    private val info = TextView(service)
    private val toggleBtn = Button(service)

    private fun dp(v: Int) = (v * service.resources.displayMetrics.density).toInt()

    private fun viewFlags(capture: Boolean): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!capture) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private val viewParams = WindowManager.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        viewFlags(false),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private val barParams = WindowManager.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.BOTTOM }

    init {
        pickView.onPick = { x, y -> onPicked(x, y) }

        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(12), dp(8), dp(12), dp(8))
        bar.background = GradientDrawable().apply {
            setColor(Color.parseColor("#F0212121"))
            cornerRadius = dp(12).toFloat()
        }
        info.setTextColor(Color.WHITE)
        info.textSize = 14f

        val row = LinearLayout(service).apply { orientation = LinearLayout.HORIZONTAL }
        toggleBtn.setOnClickListener { if (!done) setCapturing(!capturing) }
        val moveBtn = Button(service).apply {
            text = "↕"
            setOnClickListener { moveBar() }
        }
        val cancelBtn = Button(service).apply {
            text = "لغو"
            setOnClickListener { finish(false) }
        }
        row.addView(toggleBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        row.addView(moveBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(cancelBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(info)
        bar.addView(row)
    }

    fun show() {
        try {
            wm.addView(pickView, viewParams)
            wm.addView(bar, barParams)
        } catch (_: Exception) {
        }
        refreshUi()
    }

    /** Removes the windows without calling onFinish. */
    fun dismiss() {
        alive = false
        handler.removeCallbacksAndMessages(null)
        try { wm.removeView(bar) } catch (_: Exception) {}
        try { wm.removeView(pickView) } catch (_: Exception) {}
    }

    private fun finish(completed: Boolean) {
        if (!alive) return
        dismiss()
        onFinish(completed)
    }

    private fun setCapturing(c: Boolean) {
        capturing = c
        viewParams.flags = viewFlags(c)
        try { wm.updateViewLayout(pickView, viewParams) } catch (_: Exception) {}
        refreshUi()
    }

    private fun moveBar() {
        barOnTop = !barOnTop
        barParams.gravity = if (barOnTop) Gravity.TOP else Gravity.BOTTOM
        try { wm.updateViewLayout(bar, barParams) } catch (_: Exception) {}
    }

    private fun refreshUi() {
        pickView.capture = capturing
        pickView.invalidate()
        if (done) return
        val s = steps[index]
        val head = "مرحله ${index + 1} از ${steps.size}: ${s.label}\n"
        if (capturing) {
            info.text = lastMsg + head + "روی صفحه، محل «${s.label}» را لمس کنید. تا انگشتتان روی صفحه است مختصات زنده نمایش داده می‌شود و با رها کردن ثبت می‌شود."
            toggleBtn.text = "حالت عبور"
        } else {
            info.text = lastMsg + head + "اول به برنامه مقصد بروید و صفحه را آماده کنید، بعد «شروع انتخاب» را بزنید."
            toggleBtn.text = "شروع انتخاب"
        }
    }

    private fun onPicked(x: Float, y: Float) {
        if (done || !alive) return
        val s = steps[index]
        val xi = x.roundToInt()
        val yi = y.roundToInt()
        prefs.edit().putString(s.kx, xi.toString()).putString(s.ky, yi.toString()).apply()
        pickView.setMark(s.mark, x, y)
        index++
        if (index >= steps.size) {
            done = true
            info.text = "✓ ${s.label}: X=$xi  Y=$yi\nهمه مختصات ثبت شد."
            handler.postDelayed({ finish(true) }, 1200)
        } else {
            lastMsg = "✓ ${s.label}: X=$xi  Y=$yi\n"
            refreshUi()
        }
    }
}
